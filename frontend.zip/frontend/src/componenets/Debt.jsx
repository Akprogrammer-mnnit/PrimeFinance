import React, { useState, useEffect } from "react";
import axios from "axios";
import { useSelector } from "react-redux";

const Debt = () => {
  const [debts, setDebts] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [newDebt, setNewDebt] = useState({
    debtAmount: "",
    interestRate: "",
    debtTakenDate: "",
    debtPayingDate: "",
    amountPaid: "",
    debtTakenFromName: "",
  });
  const [editingDebt, setEditingDebt] = useState({
    _id: "",
    debtAmount: "",
    interestRate: "",
    debtTakenDate: "",
    debtPayingDate: "",
    amountPaid: "",
    debtTakenFromName: "",
  });
  const [showUpdatePopUp, setShowUpdatePopup] = useState(false);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const userData = useSelector(state => state.auth.userData);
  const extractDate = (dateString) => {
    return dateString ? dateString.split("T")[0] : ""; // Extract the date part
  };
  const formatDate = (date) => {
    // Convert the date to 'yyyy-MM-dd' format
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0'); // months are 0-indexed
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };


  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewDebt((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };
  const handleInputChangeUpdate = (e) => {
    const { name, value } = e.target;
    setEditingDebt((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      const formattedDebt = {
        ...newDebt,
        debtTakenDate: formatDate(newDebt.debtTakenDate),
        debtPayingDate: formatDate(newDebt.debtPayingDate),
      };
      const response = await axios.post("http://localhost:8000/api/v1/debt/create-debt", formattedDebt, {
        withCredentials: true,
      });
      setDebts((prevState) => [...prevState, response.data.message]);
      setNewDebt({
        debtAmount: "",
        interestRate: "",
        debtTakenDate: "",
        debtPayingDate: "",
        amountPaid: "",
        debtTakenFromName: "",
      });
    } catch (error) {
      setError("Failed to create debt");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (debtId) => {
    try {
      await axios.delete(`http://localhost:8000/api/v1/debt/delete-debt/${debtId}`, {
        withCredentials: true,
      });
      setDebts(debts.filter((debt) => debt._id !== debtId));
    } catch (error) {
      setError("Failed to delete debt");
    }
  };

  // Start editing a debt

  // Calculate the total amount to be paid (debt amount + interest)
  const calculateTotalDebt = (debtAmount, interestRate) => {
    return debtAmount + (debtAmount * interestRate) / 100;
  };

  // Get the status color based on the debt status
  const getStatusColor = (status) => {
    switch (status) {
      case "Pending":
        return "bg-yellow-300 text-yellow-800";
      case "Paid":
        return "bg-green-300 text-green-800";
      case "Overdue":
        return "bg-red-300 text-red-800";
      default:
        return "bg-gray-200 text-gray-700";
    }
  };

  useEffect(() => {
    const fetchDebts = async () => {
      try {
        setLoading(true);
        const response = await axios.get("http://localhost:8000/api/v1/debt/", {
          params: { page: currentPage, query: searchQuery, userId: userData?._id },
          withCredentials: true,
        });
        setDebts(response.data.message.debts);
        setTotalPages(response.data.message.totalPages);
      } catch (error) {
        console.log("Failed to fetch debts: ", error);
      } finally {
        setLoading(false);
      }
    };

    fetchDebts();
  }, [currentPage, searchQuery, userData]);

  const handleEdit = async (debtId) => {
    await axios.get(`http://localhost:8000/api/v1/debt/getDebtById/${debtId}`, {
      withCredentials: true,
    })
      .then((response) => {
        if (response) {
          setShowUpdatePopup(true);
          setEditingDebt({
            _id: response.data.message._id,
            debtAmount: response.data.message.debtAmount,
            interestRate: response.data.message.interestRate,
            debtTakenDate: extractDate(response.data.message.debtTakenDate),
            debtPayingDate: extractDate(response.data.message.debtPayingDate),
            amountPaid: response.data.message.amountPaid,
            debtTakenFromName: response.data.message.debtTakenFromName,
          });
        }
      })
      .catch((error) => {
        console.error("Failed to fetch debt: ", error);
      })
  }
  const handleUpdate = async () => {
    await axios.post(`http://localhost:8000/api/v1/debt/update-debt/${editingDebt._id}`, editingDebt, {
      withCredentials: true,
    })
      .then((response) => {
        console.log(response)
        setDebts((prevDebts) =>
          prevDebts.map((debt) =>
            debt._id === response.data.message._id ? { ...debt, ...response.date.message } : debt
          )
        );
        setShowUpdatePopup(false);
      })
      .catch((error) => {
        console.error("Failed to update debt: ", error);
      })
  }
  return (
    <div className="container mx-auto p-6 bg-gray-100 rounded-lg shadow-lg">
      <h1 className="text-3xl font-bold text-center mb-6 text-blue-600">Manage Debts</h1>

      {error && (
        <div className="mb-4 text-red-600 bg-red-100 p-2 rounded-md">{error}</div>
      )}

      <div className="max-w-lg mx-auto mb-8 bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-semibold mb-4 text-blue-600">Create Debt</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-gray-700">Amount</label>
            <input
              type="number"
              name="debtAmount"
              value={newDebt.debtAmount}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border rounded-md"
              placeholder="Enter debt amount"
              required
            />
          </div>

          <div>
            <label className="block text-gray-700">Interest Rate (%)</label>
            <input
              type="number"
              name="interestRate"
              value={newDebt.interestRate}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border rounded-md"
              placeholder="Enter interest rate"
              required
            />
          </div>

          <div>
            <label className="block text-gray-700">Debt Taken Date</label>
            <input
              type="date"
              name="debtTakenDate"
              value={newDebt.debtTakenDate}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border rounded-md"
              required
            />
          </div>

          <div>
            <label className="block text-gray-700">Debt Paying Date</label>
            <input
              type="date"
              name="debtPayingDate"
              value={newDebt.debtPayingDate}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border rounded-md"
              required
            />
          </div>

          <div>
            <label className="block text-gray-700">Amount Paid </label>
            <input
              type="number"
              name="amountPaid"
              value={newDebt.amountPaid}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border rounded-md"
              placeholder="Enter amount paid till date"
            />
          </div>

          <div>
            <label className="block text-gray-700">Debt Taken From Name</label>
            <input
              type="text"
              name="debtTakenFromName"
              value={newDebt.debtTakenFromName}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border rounded-md"
              placeholder="Enter the lender's name"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full py-2 bg-blue-600 text-white font-semibold rounded-md"
            disabled={loading}
          >
            {loading ? "Processing..." : "Create Debt"}
          </button>
        </form>
      </div>

      {/* Search Input */}
      <div className="mb-6">
        <input
          type="text"
          placeholder="Search debts..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="border rounded-md px-4 py-2 w-full"
        />
      </div>

      {/* Display All Debts */}
      <div>
        <h2 className="text-2xl font-semibold mb-4">Your Debts</h2>
        {loading ? (
          <p>Loading...</p>
        ) : (
          <div className="space-y-4">
            {debts.length > 0 ? (
              debts.map((debt) => (
                <div key={debt._id} className="bg-white p-6 border rounded-md shadow-lg">
                  <h3 className="text-xl font-semibold text-blue-600">
                    {debt.debtTakenFromName}
                  </h3>
                  <div>
                    <p>Amount: ₹{debt.debtAmount}</p>
                    <p>Interest Rate: {debt.interestRate}%</p>
                    <p>
                      Remaining Amount: ₹
                      {calculateTotalDebt(debt.debtAmount, debt.interestRate) - debt.amountPaid}
                    </p>
                    <p>
                      Total Amount Paid: ₹{debt.amountPaid}
                    </p>
                    <p>
                      Debt Taken Date:{" "}
                      {new Date(debt.debtTakenDate).toLocaleDateString()}
                    </p>
                    <p>
                      Debt Paying Date:{" "}
                      {new Date(debt.debtPayingDate).toLocaleDateString()}
                    </p>
                    <div
                      className={`inline-block py-1 px-3 rounded-full ${getStatusColor(
                        debt.status
                      )}`}
                    >
                      {debt.status}
                    </div>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <button
                      onClick={() => handleDelete(debt._id)}
                      className="text-red-600 bg-red-100 px-4 py-2 rounded-md"
                    >
                      Delete
                    </button>

                    <button
                      onClick={() => handleEdit(debt._id)}
                      className="text-blue-600 bg-blue-100 px-4 py-2 rounded-md"
                    >
                      Update
                    </button>

                  </div>
                </div>
              ))
            ) : (
              <p>No debts found.</p>
            )}
          </div>
        )}
      </div>

      {/* Pagination */}
      <div className="flex justify-center items-center mt-6 space-x-4">
        <button
          disabled={currentPage === 1}
          onClick={() => setCurrentPage(currentPage - 1)}
          className="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400 disabled:opacity-50"
        >
          Previous
        </button>
        <span>Page {currentPage} of {totalPages}</span>
        <button
          disabled={currentPage === totalPages}
          onClick={() => setCurrentPage(currentPage + 1)}
          className="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400 disabled:opacity-50"
        >
          Next
        </button>
      </div>





      {
        showUpdatePopUp ? (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-lg">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-800">Update Debt</h2>
                <button
                  onClick={() => setShowUpdatePopup(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  ×
                </button>
              </div>
              <form onSubmit={handleUpdate} className="space-y-4">
                <div>
                  <label className="block text-gray-700">Amount</label>
                  <input
                    type="number"
                    name="debtAmount"
                    value={editingDebt.debtAmount}
                    onChange={handleInputChangeUpdate}
                    className="w-full px-4 py-2 border rounded-md"
                    placeholder="Enter debt amount"
                    required
                  />
                </div>

                <div>
                  <label className="block text-gray-700">Interest Rate (%)</label>
                  <input
                    type="number"
                    name="interestRate"
                    value={editingDebt.interestRate}
                    onChange={handleInputChangeUpdate}
                    className="w-full px-4 py-2 border rounded-md"
                    placeholder="Enter interest rate"
                    required
                  />
                </div>

                <div>
                  <label className="block text-gray-700">Debt Taken Date</label>
                  <input
                    type="date"
                    name="debtTakenDate"
                    value={editingDebt.debtTakenDate}
                    onChange={handleInputChangeUpdate}
                    className="w-full px-4 py-2 border rounded-md"
                    required
                  />
                </div>

                <div>
                  <label className="block text-gray-700">Debt Paying Date</label>
                  <input
                    type="date"
                    name="debtPayingDate"
                    value={editingDebt.debtPayingDate}
                    onChange={handleInputChangeUpdate}
                    className="w-full px-4 py-2 border rounded-md"
                    required
                  />
                </div>

                <div>
                  <label className="block text-gray-700">Amount Paid</label>
                  <input
                    type="number"
                    name="amountPaid"
                    value={editingDebt.amountPaid}
                    onChange={handleInputChangeUpdate}
                    className="w-full px-4 py-2 border rounded-md"
                    placeholder="Amount paid till date"
                  />
                </div>

                <div>
                  <label className="block text-gray-700">Debt Taken From Name</label>
                  <input
                    type="text"
                    name="debtTakenFromName"
                    value={editingDebt.debtTakenFromName}
                    onChange={handleInputChangeUpdate}
                    className="w-full px-4 py-2 border rounded-md"
                    placeholder="Enter the lender's name"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2 bg-blue-600 text-white font-semibold rounded-md"
                  disabled={loading}
                >
                  {loading ? "Processing..." : "Update Debt"}
                </button>
              </form>
            </div>
          </div>
        ) : (null)
      }
    </div >
  );
};

export default Debt;
