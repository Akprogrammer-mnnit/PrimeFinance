import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area,
} from "recharts";

const Dashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:8000/api/v1/dashboard/", { withCredentials: true });
        console.log(response);
        setDashboardData(response.data.message);
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      }
    };

    fetchData();
  }, []);

  if (!dashboardData) return <p className="text-center text-gray-600">Loading...</p>;

  const { incomeDetails, expenseDetails, statusBreakdown, debtByCreditor, paymentsByFrequency, upcomingPayments, monthlyExpenses, monthlyIncomes } = dashboardData;


  const getMonthlyIncome = () => {
    let total = 0;
    monthlyIncomes.map((obj) => {
      total += obj.totalAmount;
    })
    return total;
  }
  const getMonthlyExpenses = () => {
    let total = 0;
    monthlyExpenses.map((obj) => {
      total += obj.totalAmount;
    })
    return total;
  }
  const COLORS = [
    "#0088FE", "#00C49F", "#FFBB28", "#FF8042",
    "#A569BD", "#1ABC9C", "#2ECC71", "#3498DB",
    "#E74C3C", "#F1C40F", "#E67E22", "#9B59B6",
    "#34495E", "#16A085", "#27AE60", "#2980B9",
    "#D35400", "#C0392B", "#BDC3C7", "#7F8C8D",
  ];

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
  ];
  const aggregatedData = Object.values(
    incomeDetails.reduce((acc, item) => {
      const key = `${item.month}-${item.year}`;
      if (!acc[key]) {
        acc[key] = { month: item.month, year: item.year, totalAmount: 0 };
      }
      acc[key].totalAmount += item.totalAmount;
      return acc;
    }, {})
  ).map(item => ({
    ...item,
    month: `${monthNames[item.month - 1]} ${item.year}`,
  }));
  return (
    <div className="container mx-auto p-6 space-y-10">
      <h1 className="text-4xl font-bold text-center mb-6 text-gray-800">Dashboard</h1>

      {/* Summary Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-r from-green-400 to-green-600 text-white p-6 rounded-lg shadow-lg">
          <h3 className="text-xl font-semibold">Total Income</h3>
          <p className="text-3xl font-bold mt-2">₹{dashboardData.totalIncome}</p>
        </div>
        <div className="bg-gradient-to-r from-red-400 to-red-600 text-white p-6 rounded-lg shadow-lg">
          <h3 className="text-xl font-semibold">Total Expenses</h3>
          <p className="text-3xl font-bold mt-2">₹{dashboardData.totalExpenses}</p>
        </div>
        <div className="bg-gradient-to-r from-indigo-400 to-indigo-600 text-white p-6 rounded-lg shadow-lg">
          <h3 className="text-xl font-semibold">Net Savings</h3>
          <p className="text-3xl font-bold mt-2">₹{dashboardData.totalIncome - dashboardData.totalExpenses}</p>
        </div>
      </div>



      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-r from-green-400 to-green-600 text-white p-6 rounded-lg shadow-lg">
          <h3 className="text-xl font-semibold">This Month Income</h3>
          <p className="text-3xl font-bold mt-2">₹{getMonthlyIncome()}</p>
        </div>
        <div className="bg-gradient-to-r from-red-400 to-red-600 text-white p-6 rounded-lg shadow-lg">
          <h3 className="text-xl font-semibold">This Month Expenses</h3>
          <p className="text-3xl font-bold mt-2">₹{getMonthlyExpenses()}</p>
        </div>
        <div className="bg-gradient-to-r from-indigo-400 to-indigo-600 text-white p-6 rounded-lg shadow-lg">
          <h3 className="text-xl font-semibold">This Month Net Saving</h3>
          <p className="text-3xl font-bold mt-2">₹{getMonthlyIncome() - getMonthlyExpenses()}</p>
        </div>
      </div>

      {/* Income vs Expenses */}
      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-2xl font-semibold mb-4 text-gray-700">Income vs Expenses</h2>
        <div className="flex justify-center">
          <BarChart
            width={600}
            height={300}
            data={[
              { name: "Income", total: dashboardData.totalIncome },
              { name: "Expenses", total: dashboardData.totalExpenses },
            ]}
          >
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="total" fill="#4CAF50" />
          </BarChart>
        </div>
      </div>

      {/* Expense Breakdown */}
      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-2xl font-semibold mb-4 text-gray-700">Expense Breakdown</h2>
        <div className="flex justify-center">
          <PieChart width={400} height={400}>
            <Pie
              data={expenseDetails}
              dataKey="totalAmount"
              nameKey="category"
              cx="50%"
              cy="50%"
              outerRadius={120}
              fill="#8884d8"
              label
            >
              {expenseDetails.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </div>
      </div>

      {/* Income Breakdown */}
      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-2xl font-semibold mb-4 text-gray-700">Income Breakdown</h2>
        <div className="flex justify-center">
          <PieChart width={400} height={400}>
            <Pie
              data={incomeDetails}
              dataKey="totalAmount"
              nameKey="category"
              cx="50%"
              cy="50%"
              outerRadius={120}
              fill="#82ca9d"
              label
            >
              {incomeDetails.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </div>
      </div>

      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-2xl font-semibold mb-4 text-gray-700">Monthly Trends</h2>
        <div className="flex justify-center">
          <LineChart width={600} height={300} data={aggregatedData}>
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="totalAmount" stroke="#0088FE" name="Income" />
          </LineChart>
        </div>
      </div>

      {/* Debt Status */}
      {Object.keys(statusBreakdown).length !== 0 ? (
        <div className="bg-white shadow-md rounded-lg p-6">
          <h2 className="text-2xl font-semibold mb-4 text-gray-700">Debt Status</h2>
          <div className="flex justify-center">
            <BarChart width={600} height={300} data={statusBreakdown}>
              <XAxis dataKey="_id" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="totalDebt" fill="#FF8042" />
              <Bar dataKey="totalOutstanding" fill="#FFBB28" />
            </BarChart>
          </div>
        </div>
      ) : (null)
      }
      {/* Recurring Payments by Frequency */}
      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-2xl font-semibold mb-4 text-gray-700">Recurring Payments by Frequency</h2>
        <div className="flex justify-center">
          <AreaChart width={600} height={300} data={paymentsByFrequency}>
            <XAxis dataKey="_id" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Area type="monotone" dataKey="totalAmount" stroke="#00C49F" fill="#00C49F" />
          </AreaChart>
        </div>
      </div>

      {/* Upcoming Payments */}
      <div className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-2xl font-semibold mb-4 text-gray-700">Upcoming Payments</h2>
        <ul className="space-y-3">
          {upcomingPayments.map((payment, index) => (
            <li key={index} className="p-4 bg-gray-50 rounded-lg shadow-sm">
              <div className="flex justify-between">
                <span className="font-medium text-gray-600">{payment.title}</span>
                <span className="font-semibold text-indigo-500">₹{payment.amount}</span>
              </div>
              <div className="text-sm text-gray-500">
                Next Payment: {new Date(payment.nextPaymentDate).toLocaleDateString()}
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default Dashboard;
