import React, { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import axios from "axios";

const SearchedUsers = () => {
    const [searchParams] = useSearchParams();
    const query = searchParams.get("query");
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (query) {
            const fetchUsers = async () => {
                setLoading(true);
                try {
                    const response = await axios.get("http://localhost:8000/api/v1/users/", { params: { query }, withCredentials: true });
                    console.log(response);
                    setUsers(response.data.message.users || []);
                } catch (error) {
                    console.error("Error fetching users:", error);
                } finally {
                    setLoading(false);
                }
            };
            fetchUsers();
        }
    }, [query]);

    return (
        <div className="p-6 max-w-lg mx-auto">
            {loading && <p>Loading...</p>}
            {!loading && users.length === 0 && <p>No users found for "{query}".</p>}
            {!loading && users.length > 0 && (
                <div className="space-y-4">
                    {users.map((user) => (
                        <div
                            key={user._id}
                            className="flex items-center space-x-4 p-4 bg-white shadow rounded-lg"
                        >
                            <img
                                src={user.avatar || "/default-avatar.png"}
                                alt={`${user.username}'s avatar`}
                                className="w-12 h-12 rounded-full object-cover"
                            />
                            <span className="text-gray-800 font-semibold">{user.username}</span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default SearchedUsers;
