import React from 'react'
import { SearchedUsers as SearchedUsersComponent, Container } from '../componenets/index.js'
function SearchedUserPage() {
    return (
        <Container>
            <SearchedUsersComponent />
        </Container>
    )
}

export default SearchedUserPage
