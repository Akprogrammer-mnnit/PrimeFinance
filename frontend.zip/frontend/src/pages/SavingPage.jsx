import React from 'react'
import { Saving as SavingComponent, Container } from '../componenets/index.js'
function SavingPage() {
    return (
        <Container>
            <SavingComponent />
        </Container>
    )
}

export default SavingPage
