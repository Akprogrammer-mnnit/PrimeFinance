import React from 'react'
import { Dashboard as DashboardComponent, Container } from '../componenets/index.js'
import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom';
function HomePage() {
    const status = useSelector(state => state.auth.status);
    if (!status) {
        return (
            <div className="flex items-center justify-center min-h-screen bg-gray-100">
                <Link
                    to="/login"
                    className="text-lg font-medium text-white bg-blue-500 px-6 py-3 rounded-lg shadow-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 transition-all"
                >
                    Please Login
                </Link>
            </div>
        );
    }
    return (
        <Container>
            <DashboardComponent />
        </Container>
    )
}

export default HomePage
