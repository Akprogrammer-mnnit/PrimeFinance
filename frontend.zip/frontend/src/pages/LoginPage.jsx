import React from 'react'
import { Login as LoginComponent, Container } from '../componenets/index.js'
function LoginPage() {
    return (
        <Container>
            <LoginComponent />
        </Container>
    )
}

export default LoginPage
