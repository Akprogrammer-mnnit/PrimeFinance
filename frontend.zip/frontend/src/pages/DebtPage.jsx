import React from 'react'
import {Debt as DebtComponent , Container} from '../componenets/index.js'
function DebtPage() {
  return (
    <Container>
      <DebtComponent />
    </Container>
  )
}

export default DebtPage
