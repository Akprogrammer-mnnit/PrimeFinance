import React from 'react'
import { RecurringPayment as RecurringPaymentComponent, Container } from '../componenets/index.js'
function RecurringPayment() {
    return (
        <Container>
            <RecurringPaymentComponent />
        </Container>
    )
}

export default RecurringPayment
