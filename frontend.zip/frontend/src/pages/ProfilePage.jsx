import React from 'react'
import { Profile as ProfileCompoenent, Container } from '../componenets/index.js'
function ProfilePage() {
    return (
        <Container>
            <ProfileCompoenent />
        </Container>
    )
}

export default ProfilePage
