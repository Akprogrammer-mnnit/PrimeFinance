import React from 'react'
import { Signup as SignupComponent, Container } from '../componenets/index.js'
function SignupPage() {
    return (
        <Container>
            <SignupComponent />
        </Container>
    )
}

export default SignupPage
